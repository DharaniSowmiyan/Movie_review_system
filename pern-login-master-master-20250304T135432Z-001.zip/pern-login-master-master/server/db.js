const Pool = require("pg").Pool;

const pool = new Pool({
    user: "postgres",
    password: "letterboxd",
    host: "localhost",
    port: 5432,
    database: "fresh"
});

module.exports = pool;